Some notes:
1)
If the user requests a chunk of memory, and that will result in the remaining free list size <= 8-byte, the allocator will allocates all of the remaining memory to the user, that is allocated size = size request + all of the remainning free memory (<= 8-byte).
2)
Some of the functions (not visible to user) are not protected by mutex lock, for example, contiguous_list() and max_free_chunk(). Such functions' critical sections are protected by their callers which are protected by the mutex lock.
3)
The program uses single linked list structure to keep track of the memory. The linked list source codes are from my assignment 1 /list file with some modifications about node's item type, function return types, sorting strategy, etc. And the linked lists used are all allocated dynamically using malloc(). 
4)
Compaction() will push all allocated chunks to the beginning of the memory and forms one single free chunk of memory (if any) after. 
5)
deallocate() will return error and rsults in doing nothing if the pointer passed is NULL. 
6)
Program logic will sort free list and used list in some cases, which results in sometimes FIRST_FIT, BEST_FIST and WORST_FIT behave the same.